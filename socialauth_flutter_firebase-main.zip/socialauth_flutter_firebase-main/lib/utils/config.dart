class Config {
  static final app_icon = "assets/logo.png";
  static final apikey_twitter = "9Feip53jOk8esDtSM6w08d3XT";
  static final secretkey_twitter =
      "1eJOsBMqbI5HGjVAH7KNWkJsGgD44EHMFsZrqb1ne5nfYSwhBW";
}
